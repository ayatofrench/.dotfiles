# Vulcan Review Prompt (Cross-Agent)

Use this in pi, Claude Code, or GitHub Copilot when generating a Vulcan review packet.

---

You are producing a PR review packet for the Vulcan automated code-gen workflow.

## Hard Rule
Do not start browser screenshots/GIF/video capture until P0/P1 findings are resolved or explicitly deferred with approval.

## Phase Budgets
- Preflight: max 5 minutes / 8 turns
- Intake + triage: max 10 minutes / 15 turns
- Fix gate: max 30 minutes / 2 retry loops

After 2 failed loops in a phase, stop and emit blocked status with root cause and next action.

## Execution Discipline
- Batch related commands where possible.
- Report status at phase boundaries (not every micro-step).
- Avoid repeating the same failing command pattern more than twice.

## Required Phase Order
1. Preflight (repo/auth/tools)
2. Intake + triage (PR + review comments)
3. Verification strategy selection (UI vs Backend/API vs Config/Infra vs Mixed)
4. Fix gate (apply fixes + targeted tests)
5. Go/No-Go decision
6. Evidence capture (browser only if strategy requires it)
7. Final packet output (HTML-first)

## GitHub Intake Commands (catalyst)
```bash
cd ~/work/catalyst
gh pr view <number> --json title,body,baseRefName,headRefName,changedFiles
gh pr diff <number>
gh api repos/AMNEngineering/catalyst/pulls/<number>/comments
```

## Go/No-Go Before Browser Capture
All must be true:
- preflight passed
- P0/P1 closure gate passed
- targeted tests pass
- no unresolved blocking infra errors
- shot list exists with assertions
- working state frozen for capture
- strategy marks browser capture as required

If any fail: NO-GO.

## Verification Strategy (Required)
- Decide strategy from changed files + triage findings:
  - `UI`: browser evidence required
  - `Backend/API`: browser not required; use tests/contracts/API checks
  - `Config/Infra`: browser not required; use config/build/runtime checks
  - `Mixed`: browser evidence only for UI claims
- Emit a short decision block before fix/evidence phases with rationale and required checks.

## Packet UX (Required)
- Put verdict + top callouts first
- Put screenshot/video evidence gallery (or non-browser evidence index) immediately after top callouts
- Put metadata + run stats in sidebar or appendix
- Ensure every evidence row has real media (no empty placeholders)

## Human Reviewer Callouts Process (Required)
- End output with `## Human Reviewer Callouts (Non-Blocking)`
- Include only applicable callouts (no yes/no lines)
- If none apply, output `- (none)`
- Treat callouts as informational only (not fix items unless there is an independent defect)
- Do not let callouts alone change verdict
- Keep emitted callout labels bold exactly as written in the template

## Output Format
Default to **HTML packet**.
Use section order from `references/packet-template.md` and structure from `references/packet-html-template.html`.

## Banned Anti-Patterns
- browser capture before triage closure
- mandatory browser capture for backend/config-only PRs
- unlimited retries
- full-suite tests by default for scoped fixes
- evidence without issue ID + assertion mapping
- unannounced scope expansion
- verification without command/output evidence
- metadata/stats before callouts/evidence
