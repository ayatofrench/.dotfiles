# Checklists

## Preflight Checklist

- [ ] VCS detected (`git` or `jj`)
- [ ] Working state is clean enough for branch operations
- [ ] `gh auth status` passes
- [ ] `node` available
- [ ] `ffmpeg` available
- [ ] test runner available
- [ ] browser automation prerequisites available

If any required check fails: **NO-GO**.

---

## Intake + Triage Checklist

- [ ] PR metadata loaded (title, base/head, changed files)
- [ ] Diff loaded
- [ ] Copilot/human review comments loaded
- [ ] GitHub intake run from `~/work/catalyst`:
  - `gh pr view <number> --json title,body,baseRefName,headRefName,changedFiles`
  - `gh pr diff <number>`
  - `gh api repos/AMNEngineering/catalyst/pulls/<number>/comments`
- [ ] Findings classified P0/P1/P2/P3
- [ ] Triage decisions captured (fix now / defer)
- [ ] Owner + rationale captured for deferred items

---

## Fix Gate Checklist

- [ ] P0/P1 items fixed or explicitly deferred with approval
- [ ] Targeted tests for touched scope pass
- [ ] No unresolved blocking infra/tool errors
- [ ] Working state frozen before capture

---

## Verification Strategy Checklist

- [ ] Strategy selected from PR scope (`UI` | `Backend/API` | `Config/Infra` | `Mixed`)
- [ ] Decision rationale recorded
- [ ] Required verification checks listed explicitly
- [ ] Browser requirement recorded (`required` | `not required`)
- [ ] Scope-to-evidence mapping defined (which claim is proven by which check/media)

---

## Go/No-Go Before Browser Capture

All must be true:

- [ ] Preflight passed
- [ ] P0/P1 closure gate passed
- [ ] Targeted tests passed
- [ ] Shot list exists
- [ ] Each shot has expected assertion
- [ ] Working state frozen for evidence
- [ ] Verification strategy says browser evidence is required

If any false: **NO-GO** (do not capture screenshots/GIF/video).

---

## Packet Assembly Checklist (HTML-First)

- [ ] Final packet rendered as **HTML**
- [ ] Top section includes verdict + P0/P1 callouts (above fold)
- [ ] Verification strategy decision is shown near top (before detailed findings)
- [ ] If browser required: screenshot/video evidence gallery appears before detailed findings
- [ ] If browser not required: non-browser evidence index (tests/contracts/config checks) appears before detailed findings
- [ ] Every shot has a real media element (`<img>`/video), not placeholder-only markup
- [ ] Metadata and run stats are in sidebar or appendix (not first section)
- [ ] Packet ends with `## Human Reviewer Callouts (Non-Blocking)` section
- [ ] Human callouts include only applicable items (no yes/no lines)
- [ ] If none apply, section contains `- (none)`
- [ ] Packet opened locally for visual verification before sharing

---

## Retry + Escalation Rule

After 2 failed loops in any phase:

Output this block and stop retries:

```md
## Blocked
- Phase:
- Symptom:
- Root cause:
- Next action:
```
